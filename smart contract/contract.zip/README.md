# Minimal Clone Factory of Vivid1155v2

Clone Vivid1155v3 contract at low gas fee

## Deploy

### yarn install

Install and update dependencies

### Add private key of account to env file

### npx hardhat run scripts/deploy.js --network polygon

Deploy smart contract
